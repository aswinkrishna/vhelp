<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller 
{
    public function __construct(){
         parent::__construct();
         $this->load->model('services/Home_model');      
         $this->load->model('M_admin');  
         $this->load->model('M_common');  
         error_reporting(E_ERROR | E_PARSE);
        // header('Content-Type: application/json');
        $this->load->helper('eq_helper');  
    }

    public function index(){

    	$output['status']   =  "1";
        $output['message']  =  ""; 

        $appSlider = $this->Home_model->getAppSlider();
        foreach ($appSlider as $key => $value) {
        	$image = 'uploads/app_slider/'.$value->slider_image;
        	if (file_exists($image) && is_file($image))
        		$image = base_url().$image;
        	else
        		$image = '';
        	$appSlider[$key]->slider_image = $image;
        }

        $output['data']['app_slider'] = $appSlider;

        $popular_service_list = $this->Home_model->getPopularServices();
        // print_r($popular_service_list);exit;
        foreach ($popular_service_list as $key => $value) {
            
            $popular_service_list[$key]->is_sub = (string) $this->Home_model->checkSubServices($value->service_type_id);
            
        	$icon = 'uploads/service_type/'.$value->service_type_icon;
        	if(file_exists($icon) && is_file($icon))
        		$icon = base_url().$icon;
        	else
        	 	$icon = "";
        	$popular_service_list[$key]->service_type_icon = $icon;

        	$banner = 'uploads/service_type/'.$value->service_type_banner_image;
        	if(file_exists($banner) && is_file($banner))
        		$banner = base_url().$banner;
        	else
        		$banner = '';
        	$popular_service_list[$key]->service_type_banner_image = $banner;

        	$thumbnail = 'uploads/service_type/'.$value->service_type_thumbnail;

        	if(file_exists($thumbnail) && is_file($thumbnail))
        		$thumbnail = base_url().$thumbnail;
        	else
        		$thumbnail = '';

        	$popular_service_list[$key]->service_type_thumbnail = $thumbnail;
        }

        $output['data']['popular_service'] = $popular_service_list;

        echo json_encode($output);exit;   
    }

    public function service_list(){

    	$output['status']   =  "0";
        $output['message']  =  "";

        $service_type_id = $this->input->post('service_type_id');
        $parent_id		 = $this->input->post('parent_id');
        $language   = ($this->input->post('language')>0?$this->input->post('language'):1);
        $search_key = $this->input->post('search_key');
        $param['search_key']    = $search_key;
        $param['language']      = $language;
        // echo $service_type_id;exit();
        $service_list = $this->Home_model->getAllServiceList($service_type_id,$parent_id,$param);
        
        foreach ($service_list as $key => $value) {
            
            $service_list[$key]->is_sub = (string) $this->Home_model->checkSubServices($value->service_type_id);
            
        	$icon = 'uploads/service_type/'.$value->service_type_icon;
        	if(file_exists($icon) && is_file($icon))
        		$icon = base_url().$icon;
        	else
        	 	$icon = "";
        	$service_list[$key]->service_type_icon = $icon;

        	$banner = 'uploads/service_type/'.$value->service_type_banner_image;
        	if(file_exists($banner) && is_file($banner))
        		$banner = base_url().$banner;
        	else
        		$banner = '';
        	$service_list[$key]->service_type_banner_image = $banner;

        	$thumbnail = 'uploads/service_type/'.$value->service_type_thumbnail;

        	if(file_exists($thumbnail) && is_file($thumbnail))
        		$thumbnail = base_url().$thumbnail;
        	else
        		$thumbnail = '';

        	$service_list[$key]->service_type_thumbnail = $thumbnail;
        }

        $output['data']['service_list'] = $this->process_services_type($service_list);
        echo json_encode($output);
    }

    public function services_question(){
        $output['status']   =  "0";
        $output['message']  =  "";
        
    	$this->form_validation->set_rules('service_type_id', 'service_type_id', 'required|numeric');

    	if ($this->form_validation->run() == FALSE){
    	    
            $output['errors'] = array('service_type_id' => form_error('service_type_id'));                  
            echo json_encode($output);
            exit;
        }else{
            
            $output['status']   = '1';
            
        	$language = $this->session->userdata('language')>0?$this->session->userdata('language'):1;
        	$con2              = ['language'=> $language,
        						  'questions_service_type_id'=> $this->input->post('service_type_id'),
        						  'question_parent_id'       => $this->input->post('question_parent_id'),
        						];
        	$service_questions = $this->Home_model->getQuestionsWithService($con2); 
        // 	echo $this->db->last_query();
        // 	print_r($service_questions);exit;
        // 	foreach ($service_questions as $key => $value) {
        	if($service_questions){
        		$answer_option = $this->Home_model->getAnswerOption($service_questions->question_id);
        		foreach($answer_option as $key1 => $value1){
        		    $answer_option[$key1]->is_sub =(string) $this->Home_model->checkAnsSubQuestion($value1->answer_options_id,$service_questions->question_id);
        		  //  echo $this->db->last_query();exit;
        		}
        		$service_questions->options = $answer_option;
        // 		print_r($answer_option);exit();
        	}

        // 	$output['data']['services_questions'] = $this->process_services_type($service_questions);
        	$output['data'] =  $service_questions; //$this->process_services_type($service_questions);
        	
        	echo json_encode($output);
        }
    }



    public function process_services_type($service_list){

    	foreach ($service_list as $key => $value) {
        	$icon = 'uploads/service_type/'.$value->service_type_icon;
        	if(file_exists($icon) && is_file($icon))
        		$icon = base_url().$icon;
        	else
        	 	$icon = "";
        	$service_list[$key]->service_type_icon = $icon;

        	$banner = 'uploads/service_type/'.$value->service_type_banner_image;
        	if(file_exists($banner) && is_file($banner))
        		$banner = base_url().$banner;
        	else
        		$banner = '';
        	$service_list[$key]->service_type_banner_image = $banner;

        	$thumbnail = 'uploads/service_type/'.$value->service_type_thumbnail;

        	if(file_exists($thumbnail) && is_file($thumbnail))
        		$thumbnail = base_url().$thumbnail;
        	else
        		$thumbnail = '';

        	$service_list[$key]->service_type_thumbnail = $thumbnail;
        }
        return $service_list;
    }

    
    public function page(){
     	$output['status']   =  "0";
        $output['message']  =  '';  

     	$this->form_validation->set_rules('uid', 'uid', 'trim|required|xss_clean');
     	if ( $this->form_validation->run() !== FALSE ) {
     		$uid = (string) $this->input->post('uid', true);
     		$output['data'] = $this->M_common->getArticles($uid);
     	}else{
     		$output['status']   =  "0";
            $output['message']  =  strip_tags(validation_errors());                   
     	}

     	echo json_encode($output);
     }
     
}