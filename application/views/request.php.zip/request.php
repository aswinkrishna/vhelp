<?php
 $cityId = $_GET['c'];
if($cityId>0)
{
  $labelHead = " in ".$this->M_common->getCityName($cityId);
}
else 
{
    $labelHead  = "";
}
$defaultLattittude = "25.204849";
$defaultlongittude = "55.270782";
$defaultLocation   ="Dubai - United Arab Emirates";
$defaultCity       ="Dubai";
$defaultState      = "United Arab Emirates";
               


$language           = $this->session->userdata("language")>0? $this->session->userdata("language"):1;       ?>


    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">


<style>
    .summery_row h3
    {
        color:white !important;
    }
  /*  .summaryUl
    {
        display:none;
    }*/
</style>
<section class="">
    <!--start container fluid-->
    <div class="container-fluid">
        <!--start row-->
        <div class="row housecleaning_banner arc_concultency" style="background:url(<?php echo base_url()?>/uploads/service_type/<?php  echo $question_list->service_type_banner_image;?>);">
            <!--start container-->
            <div class="container">
                <!--start row-->
                <div class="row">
                    
                    <div class="col-md-9 auto">
                    <h3><?php  echo $question_list->main_label.$labelHead;?></h3>

                    <h5>
               <?php echo $question_list->sub_label ?>                       
                    </h5>                        

                    </div>

                </div>
                <!--end row-->
            </div>
            <!--end container-->
        </div>
        <!--end row-->
    </div>
    <!--end container fluid-->
</section>
<!--end banner section-->








<!--start section-->
<section>
    <!--start container fluid-->
    <div class="container-fluid">
        <!--start row-->
        <div class="row">
            <!--start container-->
            <div class="container">
                <!--start row-->
                <div class="row tab_padd">
                    
                    <!-- <div class="col-md-12 tab_menu_box">
                        <ul class="nav nav-pills n" id="pills-tab" role="tablist">
                      <li class="nav-item tab-nav tab1">
                           <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#homecleaning" role="tab" aria-controls="pills-home" aria-selected="true"><aside></aside>  <?php  echo $question_list->service_type_name;?></a>
                      </li>
                      <li class="nav-item tab-nav tab2">
                           <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#description" role="tab" aria-controls="pills-profile" aria-selected="false"><aside></aside>  Description </a>
                     </li>
                     
                      <li class="nav-item tab-nav tab3">
                           <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#faq" role="tab" aria-controls="pills-contact" aria-selected="false"><aside></aside>  Faq</a>
                      </li>
                      
                      
                      <li class="nav-item tab-nav tab4">
                           <a class="nav-link" id="ri" data-toggle="pill" href="#review" role="tab" aria-controls="pills-contact" aria-selected="false"><aside></aside>  Review</a>
                      </li>
                   </ul>
                    </div> -->

                   <!--start tab-->
                   
                   
                   
                   
<div class="tab-content container-fluid" id="pills-tabContent">
 
 
 <!--tab 1-->                          
<div class="tab-pane  show active row tab_content_padd " id="homecleaning" role="tabpanel" aria-labelledby="pills-home-tab">
    <h4 class="service-title"> <?php  echo $question_list->service_type_name;?></h4>
  <!--start col md 11-->
     <div class="col-md-11 auto">
      

     <div class="line-hr"></div>
     <div class="row tab_inner">
         
         <div class="bullet need-user first-bullet"> <span>Your needs</span> </div>
         <div class="bullet location-selection pan" id="locationPan"> <span>your location</span> </div>
         <div class="bullet payment-selection pan" id="selectOption"> <span>Quotation / Select Provider</span> </div>
         <div class="bullet done pan" id="page-succes"> <span>done</span> </div>
     </div>

     </div><!--end col md 11-->
     
 <!--start page wrapp-->
 <div class="pageWrapp questionArea" id="questionArea">

     
 <div class="col-md-12 auto">
     
     <!--start container fluid-->
     <div class="container-fluid">
         <!--start row-->
         <div class="row row_margin_top">
             
            <input type="hidden" value="1" id="currentQyestion">
            <form id="dynamicForm" class="col-md-8 col-sm-6 select_services">
                
                
           <!--start col md 8-->
            <div class="col-md-8 col-sm-6 select_services" id="dynamicQuestionArea">
                 
             <?php
             $language           = $this->session->userdata("language")>0? $this->session->userdata("language"):1;     
             $i=1;
            $is_home_category =0;
            // print_r($question_list);
             if (count($question_list)>0)
             {
              
                    $rows = $question_list;
                      $is_home_category  = $rows->is_home_category;
                 if($i==1)
                 {
                     $style= "";
                 }
                 else
                 {
                     $style ="none";
                 }
                 $con['question_id']    =  $rows->question_id;
                  $answers                     =   $this->M_request->getAnswers($con)     ; 
                  
                   if($rows->question_parent_id<=0)
                   {
                        $lastParent  =  $rows->question_id;
                   }
                   else
                   {
                        $lastParent  =  $rows->question_id;
                   }
                 
             ?>
<!--start row-->
<span id="span<?php echo $rows->question_id ?>" class="commonDisplayQuestion">
<div class="row choose_options" style="display:<?php echo $style;?>" id="div<?php echo $rows->question_id ?>">
<h3><?php echo $language==2 && $rows->question_arb!=""?$rows->question_arb:$rows->question ; ?></h3>

    
      <?php
      $k=1;
                            if($rows->question_form_type==1)
                                {
                                ?>
                              
                                 <input type="text" class="form-control boxed dynamicQues" for="<?php echo $rows->question_id ?>" placeholder="" name="question[<?php echo $rows->question_id ?>][]"  id="dynamicQues<?php echo $rows->question_id ?>" value="" maxlength="100" autocomplete="off" style="display:block">
                                <?php
                                }
                                else  if($rows->question_form_type==6)
                                {
                                ?>
                                 <textarea class="form-control boxed dynamicQues" for="<?php echo $rows->question_id ?>" placeholder="" name="question[<?php echo $rows->question_id ?>][]"  id="dynamicQues<?php echo $rows->question_id ?>" value=""  autocomplete="off"></textarea>
                                <?php
                                }
                                    if(count($answers)>0)
                                    {
                                        
                                        if($rows->question_form_type==2 || $rows->question_form_type==3)
                                   {
                                    ?>
                                    <select class="form-control dynamicQues" for="<?php echo $rows->question_id ?>"    name="question[<?php echo $rows->question_id ?>][]"  id="dynamicQues<?php echo $rows->question_id ?>" <?php echo $rows->question_form_type==3?"multiple":"" ?>>
                                    <option value="">Select</option>
                                   <?php
                                   }
                                 /*   if($rows->question_form_type==4)
                                {
                                    ?>
                                   <ul class="options">     
                                   <?php
                                }else if($rows->question_form_type==5)
                                {
                                  ?>
                                    <ul class=""> 
                                  <?php
                                }
                                        */
                                        ?>
                                        <ul class="options">   
                                        <?php
                                        foreach($answers as $rows2)
                                        {
                                    ?>
<li>
    <?php
    
    if($rows->question_form_type==4)
                                {
                                   
    ?>
 <input data-text="<?php  echo $rows2->answer_option ?>"  for="<?php echo $rows->question_id ?>" id="dynamicQues<?php  echo $rows2->answer_options_id ?>" name="question[<?php echo $rows->question_id ?>][]" type="radio" value="<?php  echo $rows2->answer_options_id ?>" data-error="#errNmQ<?php echo $rows->question_id ?>" data-price="<?php  echo $rows2->price ?>" class="hide radio<?php echo $rows->question_id ?> answerRadios"  >
  <label for="dynamicQues<?php  echo $rows2->answer_options_id ?>"><?php  echo $rows2->answer_option ?></label>   
   
  <?php
                                 }
                                  if($rows->question_form_type==5)
                                {
                                   
    ?>
    
                  <label class="form-check-label"> <input class="form-check-input dynamicQues radio<?php echo $rows->question_id ?> answerRadios" data-text="<?php  echo $rows2->answer_option ?>" for="<?php echo $rows->question_id ?>" id="dynamicQues<?php  echo $k?>" name="question[<?php echo $rows->question_id ?>][]" type="checkbox" value="<?php  echo $rows2->answer_options_id ?>" data-error="#errNmQ<?php echo $rows->question_id ?>" data-price="<?php  echo $rows2->price ?>"> <?php  echo $rows2->answer_option ?> <span class="dynamicCheckSpan"></span>  </label>  
  <?php
                                 }
                                 else if($rows->question_form_type==2)
                                 {
                                     ?>
                                      <option value="<?php  echo $rows2->answer_options_id ?>"  data-text="<?php  echo $rows2->answer_option ?>" data-price="<?php  echo $rows2->price ?>"><?php  echo $rows2->answer_option ?></option>
                                     <?php
                                     
                                 }
                                 ?>

</li>
 <?php
 $k++;
                                        }
                                        
                                        
                                       if($rows->question_form_type==2)
                                   {
                                       ?>
                                       </select>
                                       <?php
                                   }
                                        
                                        
                                    }
                                    ?>

</ul>
 
</div>
   <div class="row">
       <?php
        if ($rows->question_id>0)
             {
                 ?>
             
     <div class="col-md-12">
        
         
            <span style="visibility:hidden;" id="firstButton" href="#" class="continue btnCountinue" id="next<?php echo $rows->question_id ?>" data-qtype="<?php echo $rows->question_form_type;?>" data-offset="0" data-current="<?php echo $rows->question_id ?>"  data-parent="<?php echo $lastParent ?>">Continue <span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"/></span></span>
     </div>
      <?php
               $remarkStyle = "display: none;";
             }
             else
             {
                $remarkStyle = "display: block;"; 
             }
                 ?>
    </div>
</span>
<?php
$i++;
   
}

?>

</div>
            </form>
<!-- Step 4 -->

<div class="choose_options col-md-8 col-sm-6 select_services" id="Upload_section" style="<?php echo $remarkStyle;?>">
<!-- <h1>File Upload!</h1>-->

<aside class="steps stepsfield step_uploads">
       <div class="form-group">
                                        <label class="col-form-label">Describe the task or project in more details</label>
                                        <textarea class="form-control" id="txtRemark" placeholder=""></textarea>


                                    </div>
    <label class="col-form-label">Please upload the relevant documents (Optional) </label>
    
<div class="bootstrap-filestyle input-group">
    <div class="custom-file">
<!--  <input type="file" class="custom-file-input" id="customFile" disabled>-->
  <input type="file" class="custom-file-input" id="customFile1">
  <label class="custom-file-label" for="customFile1" id="labelcustomFile1">Upload Your File 1</label>
  <span class="buttonText"><i class="fa fa-plus"></i></span>
</div>
<!--    <input type="text" class="form-control" id="filepath" placeholder="Upload Your File" disabled=""> -->
    <span class="group-span-filestyle input-group-btn AddRow" tabindex="0">
        <label for="filestyle-0" class="btn btn-default "><span class="icon-span-filestyle glyphicon glyphicon-folder-open"></span> 
        <span class="buttonText"><i class="fa fa-plus"></i></span></label>
    </span>
    <span class="fileUplaodWarning instruction">Max upload size:20MB, (pdf,doc,jpg,jpeg,png)</span>
    </div>
  <!--  <div class="input-group filestyle-group">
        <input type="file" class="filestyle" placeholder="Text" id="filestyle-0" tabindex="-1" style="position: absolute; clip: rect(0px, 0px, 0px, 0px);" ><div class="bootstrap-filestyle input-group">
                                            <input type="text" class="form-control" id="filepath" placeholder="Upload Your File"  disabled="disabled">
                                            <span class="group-span-filestyle input-group-btn" tabindex="0">
                                                <label for="filestyle-0" class="btn btn-default "><span class="icon-span-filestyle glyphicon glyphicon-folder-open"></span> <span class="buttonText"><i class="fa fa-plus"></i></span></label></span></div>
                                    </div>-->

                                 

                                </aside>
<div class="row">
    
   <?php
        if ($rows->question_id>0)
             {
                 ?>
    <div class="col-md-4" id="divBackFromRemark">
            <span href="#" class="continue back" id="backFromRemark"><span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"/></span> Back</span>
          
     </div>   
     
     <?php
             }
     ?>
     <div class="col-md-4">
<!--            <span href="#" class="continue back" id="back-3"><span><img src="images/icons/right-arow.png"/></span> Back</span>-->
            <span href="#" class="continue" id="fileUploadNext">Continue <span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"/></span></span>
     </div>
</div>
</div>
<!--end row-->
 <!--start col md 4-->
             <div class="col-md-4 col-sm-6">
                 <div class="row">
                 <!--start summery_row-->
                 <div class="summery_row">
                     <div class="call-center-pattern"></div>
                     <h3>Service Summary</h3>
                     <span class="spanSummery">
                            <ul class="summaryUl">
                                  <p class="noselect">You didn't choose any Services</p>
                            </ul>
                     </span>
                     <p class="serviceTotPrice"><strong></strong></p>

                 </div>
                 
                 

                 <!--end summery_row-->
                 <div class="caricature-call-center">
                     <img src="<?php echo base_url();?>frontend_assets/images/icons/call-center.png"/>
                 </div>
                 </div>
             </div>
             <!--end col md 4-->
             </div>
             <!--end col md 8-->
             
            
            
         </div>
         <!--end row-->
         
         
     </div>
     </div>
     <!--end container fluid-->
     
     
     <?php 
     if($is_home_category==1)
     {
     ?>
     
 <!--start page wrapper 2-->
 <div class="pageWrapp page-ctrl locationPan">
  <div class="select_services">
  <h3>Please choose your location</h3>
<br>
     
</div>   
 <div class="row">
 <div class="col-md-8">
<!--
     <div class="row">
         <div class="col-sm">
             <div class="location_button active">
                 <span class="icons"><img src="images/icons/home_work.png" /></span>
                 <span>Home</span>
             </div>
         </div>
         <div class="col-sm">
             <div class="location_button">
                 <span class="icons"><img src="images/icons/work_whit.png" /></span>
                 <span>Work</span>
             </div>
         </div>
         <div class="col-sm">
             <div class="location_button">
                 <span class="icons"><img src="images/icons/other_works.png" /></span>
                 <span>Other</span>
             </div>
         </div>
     </div>
-->
<!--     <h1>Page2</h1>-->
     <div class="card_step ">
         <div class="row">
             <div class="col-md-6">
                 <div class="calender_wrap">
<!--                     <h3>Select Date</h3>-->
<!--                     <div id="my-calendar"></div>-->
                     <div class="map">
                        <div id="MAP1" style="width: 100%; height: 280px;"></div>
                     </div>

                 </div>
             </div>
             <div class="col-md-6">
             <div class="form">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Street:</div>
                                                </div>
                                                <input class="form-control autocomplete" id="us5-street1" name="us5-street1" value="<?php echo $defaultLocation;?>" >
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">City:</div>
                                                </div>
                                                <input class="form-control" id="us5-city" name="us5-city"  disabled="disabled" value="<?php echo $defaultCity;?>" >
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">State or Province:</div>
                                                </div>
                                                <input class="form-control" id="us5-state" name="us5-state"  disabled="disabled" value="<?php echo $defaultState;?>">
                                            </div>
                                            <div class="input-group mb-3 d-none">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Postal code:</div>
                                                </div>
                                                <input class="form-control" id="us5-zip" disabled="disabled">
                                            </div>
                                            <div class="input-group mb-3 d-none">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Country:</div>
                                                </div>
                                                <input class="form-control" id="us5-country" disabled="disabled">
                                            </div>
                  <input  type="hidden" class="form-control" id="us2-lat"  name="us2-lat" value="<?php echo $defaultLattittude;?>">
                   <input type="hidden" class="form-control" id="us2-lon"  name="us2-lon" value="<?php echo $defaultlongittude;?>">
             
                                        </div>
<!--
                 <div class="select_time">
                     <h3>Select Time</h3>
                     <div class="time_slotes owl-carousel">
                         <span class="badge active badge-pill">10:30 AM</span>
                         <span class="badge badge-pill">10:30 AM</span>
                         <span class="badge badge-pill">10:30 AM</span>
                         <span class="badge badge-pill">10:30 AM</span>
                         <span class="badge badge-pill">10:30 AM</span>
                         <span class="badge badge-pill">10:30 AM</span>
                         <span class="badge badge-pill">10:30 AM</span>
                         <span class="badge badge-pill">10:30 AM</span>
                     </div>
                 </div>
                 <div class="price_range">
                     <h3>Price Range</h3>
                      <div id="time-range">
    
    <div class="sliders_step1">
        <div id="slider-range"></div>
    </div>
    <div class="price_wrap">
        <p class="slider-amount-1">Min Price <span>AED 100</span></p>
        <p class="slider-amount-2">Max Price <span>AED 3000</span></p>
    </div>
</div>
                 </div>
-->
                 
                 <div class="time_date">
                    <div class="row">
                     <div class="col-sm-6">
                         <h3>Work Expiry Date</h3>
                        <div class="form-group">
                            <div class="input-group date" data-target-input="nearest">
                                <input type="text" id="datetimepicker4" class="form-control datetimepicker-input" data-target="#datetimepicker4" placeholder="" readonly />
                                <div class="input-group-append" data-target="#datetimepicker4" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="far fa-calendar-alt"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                         <h3>Work Expiry Time</h3>
                        <div class="form-group">
                            <div class="input-group date" data-target-input="nearest">
                    <input type="text" id="datetimepicker3" class="form-control datetimepicker-input" data-target="#datetimepicker3" placeholder=""/>
                    <div class="input-group-append" data-target="#datetimepicker3" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
                        </div>
                    </div>
                    </div>
                 </div>
             </div>
         </div>
     </div>
        <div class="row">
        <div class="col-md-4">
                 <span href="#" style="margin-right: 11px;width;auto" class="continue back" id="homeSettingsBack"><span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"/></span> Back
                
         </div>
          <div class="col-md-4">
                 
                 &nbsp;<span style="margin-right: 11px;width;auto" href="#" class="continue" id="btnLocationNext">Continue <span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"/></span></span>
         </div>
         
         </div>
     </div>
     <div class="col-md-4">
         <div class="row">
                 <!--start summery_row-->
                 <div class="summery_row">
                      <div class="call-center-pattern"></div>
                     <h3>Service Summary</h3>
                     
                     <span class="spanSummery">
                      <ul class="summaryUl">
                                  <p class="noselect">You didn't choose any Services</p>
                            </ul>
                     </span>
                     <p class="serviceTotPrice"><strong></strong></p>

                 </div>
                 
                 <!--end summery_row-->
                   <div class="caricature-call-center">
                     <img src="<?php echo base_url();?>frontend_assets/images/icons/call-center.png"/>
                 </div>
                 </div>
     </div>
 </div>
 </div>
 
 <?php
     }else
     {
 ?>
 <div class="pageWrapp page-ctrl  locationPan">
 <div class="row">
 <div class="col-md-8">
     <div class="row">
         <div class="col-sm">
             <div class="location_button active" for="1">
                 <span class="icons"><img src="<?php echo base_url();?>frontend_assets/images/icons/home_work.png" /></span>
                 <span>Home</span>
             </div>
         </div>
         <div class="col-sm">
             <div class="location_button" for="2">
                 <span class="icons"><img src="<?php echo base_url();?>frontend_assets/images/icons/work_whit.png" /></span>
                 <span>Work</span>
             </div>
         </div>
         <div class="col-sm">
             <div class="location_button" for="3">
                 <span class="icons"><img src="<?php echo base_url();?>frontend_assets/images/icons/other_works.png" /></span>
                 <span>Other</span>
             </div>
         </div>
     </div>
<!--     <h1>Page2</h1>-->
     <div class="card_step calendar-elegance">
         <div class="row">
             <div class="col-md-6">
                 <div class="calender_wrap">
                     <h3>Select Date</h3>
                     <div class="label-indicate"><div><span class="blue"></span><p>Not Available</p></div><div><span class="green"></span><p>Today Date</p></div><div><span class="light-blue"></span><p>Available</p></div></div>
                     
                     <div id="my-calendar"></div>
                 </div>
             </div>
             <div class="col-md-6">
                 <div class="select_time">
                     <h3>Select Time</h3>
                        <div class="label-indicate">
                            <div><span class="dark-green"></span><p> Available</p></div>
                            </div>
                     <!--owl-carousel-->
                     <div class="time_slotes test">
                         
                         <span class="badge active badge-pill">09:00 AM</span>
                         <span class="badge badge-pill">09:30 AM</span>
                         <span class="badge badge-pill">10:00 AM</span>
                         <span class="badge badge-pill">10:30 AM</span>
                         <span class="badge badge-pill">11:00 AM</span>
                         <span class="badge badge-pill">11:30 AM</span>
                         <span class="badge badge-pill">12:00 PM</span>
                         <span class="badge badge-pill">12:30 PM</span>
                         <span class="badge badge-pill">01:00 PM</span>
                         <span class="badge badge-pill">01:30 PM</span>
                         <span class="badge badge-pill">02:00 PM</span>
                         <span class="badge badge-pill">02:30 PM</span>
                         <span class="badge badge-pill">03:00 PM</span>
                         <span class="badge badge-pill">03:30 PM</span>
                         <span class="badge badge-pill">04:00 PM</span>
                         <span class="badge badge-pill">04:30 PM</span>
                         <span class="badge badge-pill">05:00 PM</span>
                         <span class="badge badge-pill">05:30 PM</span>
                         <span class="badge badge-pill">06:00 PM</span>
                         <!--<span class="badge badge-pill">06:30 PM</span>
                         <span class="badge badge-pill">07:00 PM</span>
                         <span class="badge badge-pill">07:30 PM</span>
                         <span class="badge badge-pill">08:00 PM</span>
                         <span class="badge badge-pill">08:30 PM</span>
                         <span class="badge badge-pill">09:00 PM</span>
                         <span class="badge badge-pill">09:30 PM</span>
                         <span class="badge badge-pill">10:00 PM</span>
                         <span class="badge badge-pill">10:30 PM</span>
                         <span class="badge badge-pill">11:00 PM</span>
                         <span class="badge badge-pill">11:30 PM</span>
                         <span class="badge badge-pill">12:00 AM</span>-->
                         
                         <!--<span class="badge badge-pill">12:30 AM</span>
                         <span class="badge badge-pill">01:00 AM</span>
                         <span class="badge badge-pill">01:30 AM</span>
                         <span class="badge badge-pill">02:00 AM</span>
                         <span class="badge badge-pill">02:30 AM</span>
                         <span class="badge badge-pill">03:00 AM</span>
                         <span class="badge badge-pill">03:30 AM</span>
                         <span class="badge badge-pill">04:00 AM</span>
                         <span class="badge badge-pill">04:30 AM</span>
                         <span class="badge badge-pill">05:00 AM</span>
                         <span class="badge badge-pill">05:30 AM</span>
                         <span class="badge badge-pill">06:00 AM</span>
                         <span class="badge badge-pill">06:30 AM</span>
                         <span class="badge badge-pill">07:00 AM</span>
                         <span class="badge badge-pill">07:30 AM</span>
                         <span class="badge badge-pill">08:00 AM</span>
                         <span class="badge badge-pill">08:30 AM</span>-->
                         
                     </div>
                 </div>
                 <div class="price_range">
                     <h3>Price Range</h3>
                      <div id="time-range">
    
    <div class="sliders_step1">
        <div id="slider-range"></div>
    </div>
    <div class="price_wrap">
        <p class="slider-amount-1">Min Price <span>AED <span id="price_from">100</span></span></p>
        <p class="slider-amount-2">Max Price <span>AED<span id="price_to"> 3000</span></span></p>
    </div>
</div>
                 </div>
                 
                 <div class="time_date job_validity">
                    <div class="row">
                     <div class="col-sm-6">
                         <h3>Job Validity Period</h3>
                        <div class="form-group">
                            <div class="input-group date" data-target-input="nearest">
                                <input type="hidden" id="service_date" value="<?php  echo date('Y-m-d'); ?>">
                                <input type="hidden" id="uae_time" value="<?php  echo date('Y-m-d'); ?>">
                                <input type="text" id="datetimepicker4" class="form-control datetimepicker-input" data-target="#datetimepicker4" placeholder="" readonly />
                                <div class="input-group-append" data-target="#datetimepicker4" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="far fa-calendar-alt"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                         <h3>Job Validity Time</h3>
                        <div class="form-group">
                            <div class="input-group date" data-target-input="nearest">
                    <input type="text" id="datetimepicker3" class="form-control datetimepicker-input" data-target="#datetimepicker3" placeholder=""/>
                    <div class="input-group-append" data-target="#datetimepicker3" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
                        </div>
                    </div>
                    </div>
                 </div>
             </div>
         </div>
     </div>
        <div class="row">
        <div class="col-md-4">
                 <span href="#" style="margin-right: 11px;width;auto" class="continue back" id="backFromValidity"><span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"/></span> Back
                
         </div>
        <div class="col-md-4">
<!--                 <span href="#" class="continue back" id="back-3"><span><img src="images/icons/right-arow.png"/></span> Back</span>-->
                 <span href="#" class="continue homeType" id="btnLocationNext">Continue <span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"/></span></span>
         </div></div>
     </div>
     <div class="col-md-4">
         <div class="row">
                 <!--start summery_row-->
                 <div class="summery_row">
                      <div class="call-center-pattern"></div>
                     <h3>Service Summary</h3>
                     
                        <span class="spanSummery">
                        <ul class="summaryUl">
                                  <p class="noselect">You didn't choose any Services</p>
                            </ul>
                     </span>
                     <p class="serviceTotPrice"><strong></strong></p>

                 </div>
                 <!--end summery_row-->
                   <div class="caricature-call-center">
                     <img src="<?php echo base_url();?>frontend_assets/images/icons/call-center.png"/>
                 </div>
                 </div>
     </div>
 </div>
 </div>
 
 <?php
     }
 
 ?>
 <!--end page wrapp 2-->
 <input type="hidden" id="paymentOptionChoosed">
 <input type="hidden" id="serviceAddress">
 <input type="hidden" id="serviceLocation">
 <input type="hidden" id="serviceTotPrice">
 <input type="hidden" id="serviceTotPricePass">
 <input type="hidden" id="serviceCurrency" value="<?=$this->config->item("currency");?>
">
  <!--start page wrapper 3-->
<div class="pageWrapp paymentOption" style="display: none;">
    <div class="row" >
      <div class="col-md-8">
        <div class="card_step">
          <div class="row">
              <div class="payment-wrapper-option">
                  
              
            <h3>Pay On Delivery</h3>
            
            <label class="custom-selection options">
  <input for="payOn" id="payOn" name="paymentOptionChoose" type="radio" value="1" class="paymentOptionChoose">
  <div  class="payment-items-wrapper">
      <img src="<?= base_url(); ?>/frontend_assets/images/icons/money-icon.png">
      <div>
          <h5>CASH</h5>
          <p>Please keep exact change handy to help us serve you better.</p>
      </div>
  </div>
  <span class="checkmark"></span>
</label>
</div>


            <!--<ul class="options">-->
            <!--  <li>-->
            <!--    <input >-->
            <!--    <label for="payOn">CASH</label>   -->
            <!--  </li>-->
            <!--</ul>-->
            
            <div class="payment-wrapper-option">
            
            <h3>Credit/Debit Cards</h3>
            
             <label class="custom-selection options">
  <input for="card" id="card" name="paymentOptionChoose" type="radio" value="2" class="paymentOptionChoose">
  <div class="payment-items-wrapper">
      <img src="<?= base_url(); ?>/frontend_assets/images/icons/credit-cards.png">
      <div>
          <h5>PAY BY DEBIT /CREDIT CARD</h5>
         <img src="<?= base_url(); ?>/frontend_assets/images/icons/card-brand.png">
      </div>
  </div>
  <span class="checkmark"></span>
</label>
</div>


            <!--<ul class="options">-->
            <!--  <li>-->
            <!--    <input >-->
            <!--    <label for="card">PAY BY DEBIT/CREDIT CARD</label>   -->
            <!--  </li>-->
            <!--</ul>-->
          </div>
          <div class="row">
            <div class="col-md-4">
              <span href="#" style="margin-right: 11px;width;auto" class="continue back" id="backfromPaymentOption"><span><img src="<?= base_url(); ?>/frontend_assets/images/icons/right-arow.png"></span> Back
              </span>
            </div>
            <div class="col-md-4">
                 <span href="#" class="continue" id="btnPaymentNext">Continue <span><img src="<?= base_url(); ?>/frontend_assets/images/icons/right-arow.png"></span></span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="row">
                 <!--start summery_row-->
                 <div class="summery_row">
                      <div class="call-center-pattern"></div>
                      <h3>Service Summary</h3>
                     
                      <span class="spanSummery">
                        <ul class="summaryUl">
                          <p class="noselect">You didn't choose any Services</p>
                        </ul>
                      </span>
                      <p class="serviceTotPrice"><strong></strong></p>
                 </div>
                 <!--end summery_row-->
                   <div class="caricature-call-center">
                     <img src="<?php echo base_url();?>frontend_assets/images/icons/call-center.png"/>
                 </div>
        </div>
      </div>
    </div>
</div>

<div class="pageWrapp summarySection" style="display: none;">
    <div class="row" >
      <div class="col-md-8">
        <div class="card_step ">
          <div class="row p-2">
            <h3>Service Summary</h3>
            <div class="summery_row ">
                  <ul class="">
              <li><label><strong><?php  echo $question_list->service_type_name;?></strong></label></li>
              <li><label><strong>Schedule</strong> <span id="service_summary_datetime"></span></label></li>
              <li>
                <label><strong><span id="service_summary_location_type"></span> - </strong><span id="service_summary_address"></span></label>
              </li>
              <li><label><strong><span id="service_summary_payment_option"></span></strong></label></li>
            </ul>
            </div>
          
          </div>
          <div class="row">
            <div class="col-md-4">
              <span href="#" style="margin-right: 11px;width;auto" class="continue back" id="backfromSummarySection"><span><img src="<?= base_url(); ?>/frontend_assets/images/icons/right-arow.png"></span> Back
              </span>
            </div>
            <div class="col-md-4">
                 <span href="#" class="continue" id="btnBookNow">Book Now <span><img src="<?= base_url(); ?>/frontend_assets/images/icons/right-arow.png"></span></span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="row">
                 <!--start summery_row-->
                 <div class="summery_row">
                      <div class="call-center-pattern"></div>
                      <h3>Bill Details</h3>
                     
                      <span class="spanSummery">
                        <ul class="summaryUl">
                          <p class="noselect">You didn't choose any Services</p>
                        </ul>
                      </span>
                      <p class="serviceTotPrice"><strong></strong></p>
                 </div>
                 <!--end summery_row-->
        </div>
    </div>
</div>

<div class="providers_wrap" style="display: none">
     
        <div class="row">
             <div class="col-md-6">
                     <input type="text" class="form-control" placeholder="Keyword" id="txt_keyword"/>
            </div>
             <div class="col-md-2" style="display:none;">
                     <div class="form-group">
                        <select class="form-control" id="txt_distance" >
                          <option>Filter by Distance</option>
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                          <option>5</option>
                        </select>
                      </div>
             </div>
             <div class="col-md-2">
                     <div class="form-group">
                        <select class="form-control" id="txt_rating">
                          <option>Filter by Rating</option>
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                          <option>5</option>
                        </select>
                      </div>
             </div>
             <div class="col-md-2">
                     <button type="submit" class="search_btn">Search</button>
             </div>
         </div>
        <div class="row">
 <div class="col-md-8">
<!--     <h1>Page2</h1>-->
     <div class="">
         <div class="row" >
             <div class="col-md-12">
                     <div class="provider_list">
                         <div class="row" id="divProvider">
                             
                             
                             
                         </div>
                     </div>

<!-- Modal -->
<div class="modal fade provider_pop" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document" id="detailDiv">
    
  </div>
</div>
             </div>
         </div>
     </div>
     </div>
     <div class="col-md-4">
         <div class="row">
                 <!--start summery_row-->
                 <div class="summery_row">
                      <div class="call-center-pattern"></div>
                     <h3>Service Summary</h3>
                     
                        <span class="spanSummery">
                             <ul class="summaryUl">
                                  <p class="noselect">You didn't choose any Services</p>
                            </ul>
                            
                       
                     </span>
                     <span class="serviceTotPrice"></span>
                 </div>
                 <!--end summery_row-->
                   <div class="caricature-call-center">
                     <img src="<?php echo base_url();?>frontend_assets/images/icons/call-center.png"/>
                 </div>
                 </div>
     </div>
 </div>
    <div class="row">
         <div class="col-md-4">

         <span href="#" class="continue back" id="backFromProviderSelection"> <span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"></span> Back</span>
                             </div>
                     <div class="col-md-4">

<!--                                     <span href="#" class="continue back" id="back-2"> <span><img src="images/icons/right-arow.png"></span> Back</span>-->
                                     <span href="#" style="margin-left: -148px;" class="continue" id="select_provider">Continue <span><img src="<?php echo base_url();?>frontend_assets/images/icons/right-arow.png"></span></span>

                             </div>
                             </div>
 </div>



 </div>
 <!--end page wrapp 3-->
 
 <!--select providers-->

 

<!-- select providers-->
   <!--start page wrapper 4-->
 <div class="pageWrapp  page-ctrl page-succes">
<!--     <h1>Page4</h1>-->
<div class="row">
 <div class="col-md-12">
 <div class="card_thanku">
                                        <!--<div class="img_wra">-->
                                        <!--    <img src="<//?php echo base_url();?>frontend_assets/images/icons/icon-done.png" class="img-fluid" alt="">-->
                                        <!--</div>-->
                                            <article>
                                                <h3 class="">YOU'RE ALL SET!</h3>
                                                <h6>What happen next?</h6>
                                                <p class="">We will send you an email shortly once your booking is comfirmed</p>
                                                 <p class="">A customer service agent may get in touch with you to confirm details of your request</p>
                                                  <p class="">You will pay cash on delivery when the service is completed</p>
                                                <a href="#" class="btn-view-book mb-3">VIEW BOOKING DETAILS</a>
                                                   <a href="<?php echo base_url();?>" class="btn btn-primary">CONTINUE SERVICES</a>
                                            </article>
                 </div>
                                </div>
                                </div>
 </div>
 <!--end page wrapp 4-->
 
 
     
</div>
<!--tab 1-->


    <!--start row-->
<!--
         <div class="row">
             
                 <a href="#" class="continue" id="next">Continue <span><img src="images/icons/right-arow.png"/></span></a>
             
         </div>
-->
         <!--end row-->

                               
                         
                         
                         
  <div class="tab-pane fade row tab_content_padd" id="description" role="tabpanel" aria-labelledby="pills-profile-tab">
      <h4>Description</h4>
  
<!--      <h1>Tab2</h1>-->
 <div class="main">
            <!--start container-->
            <div class="container">
                <!--start row-->
                  <div class="content">
                      <p><?php  echo $question_list->service_type_desc;?></p>
                  </div>
	
                </div>
                <!--end row-->
            </div>
  </div>
  
  <div class="tab-pane fade row tab_content_padd" id="faq" role="tabpanel" aria-labelledby="pills-contact-tab">
<!--      <h1>Tab3</h1>-->
      <h4>FAQ</h4>
 
 <div class="main">
            <!--start container-->
            <div class="container">
                <!--start row-->
              
                   <div id="accordion" class="accordion">
        <div class="card mb-0">
            <?php if(count($faq)>0)
            { 
                $k=1;
            foreach($faq as $rows)
            {
            
            ?>
            <div class="card-header collapsed" data-toggle="collapse" href="#collapseOne<?php echo $k;?>">
                <a class="card-title">
                    <?php echo $rows->service_faq ?>
                </a>
            </div>
            <div id="collapseOne<?php echo $k;?>" class="card-body collapse" data-parent="#accordion" >
                <p><?php echo $rows->service_faq_answer ?>
                </p>
            </div>
            <?php
            $k++;
            }
            }
            ?>
            
            
            
        </div>
    </div>
	
                </div>
                <!--end row-->
            </div>
  </div>
  
<div class="tab-pane fade row tab_content_padd review" id="review" role="tabpanel" aria-labelledby="pills-contact-tab ">
      <h4>Latest Reviews</h4>
      
      <!--start container fluid -->
      <div class="container-fluid">
          <!--start row-->
          <div class="row">
              <!--start col md 12-->
              <div class="col-md-12">
                  
                  <?php   
                  if(count($testimonial)>0)
                  {
                      $j=1;
                      foreach($testimonial as $rows)
                      {
                          if($j<=5)
                          {
                              $firstCharacterfirstName  = substr($rows->first_name, 0, 1);
                              $firstCharacterlastName  = substr($rows->last_name, 0, 1);
                              $displayName =  $firstCharacterfirstName.$firstCharacterlastName;
                  ?>
                 <!--start row-->
                 <div class="row review_pannel">
                     <h5><span><i class="fas fa-quote-left"></i></span>  <span><?php echo $rows->testimonial_arabic!="" && $this->session->userdata("language")==2?$rows->testimonial_arabic:$rows->testimonial?></span> </h5>
                     <div class="wrapper_row name-col"><aside><?php echo strtoupper($displayName); ?></aside> <span><?php echo $rows->first_name." ".$rows->last_name?></span></div>
                 </div>
                 <!--end row-->
                 
                 <?php
                          }
                 $j++;
                      }
                  }
                 
                 ?>
                 
                              
                 
                 
              </div>
              <!--end col md 12-->
          </div>
          <!--end row-->
      </div>
      <!--end container fluid-->
  </div>
  
</div>
                   <!--end tab-->
             </div><!--end row-->
            </div>
            <!--end container-->
        </div>
        <!--end row-->
    </div>
    <!--end container fluid-->
</section>
<!--end section-->
    
    











<!--start section-->
<?php $this->load->view('how_is_it_work'); ?>

<!--end section-->
    






















<!--end section-->
<!-- Modal -->
<div class="modal fade provider_pop" id="loactionUpdate" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document" id="loactionUpdateDIv">
     <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Update location</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <form id="formDynamicLocation">
      <div class="modal-body" id="locationDynamic">
         <div class="row">
                  
                     <div class="col-md-12">
                     <div class="location_wrap">
                       <div class="form-group">
                            <label for="exampleFormControlInput1" id="addressTypeLabel" style="color:#0e688d"><i class="far fa-check-circle"></i> Home</label>
                            <input type="text" class="form-control" id="pickup-input2" name="pickup-input2" placeholder="Location" value="<?php echo $homeLocation ?>">
                            <input type="hidden" class="form-control" id="pickup-lattitude2" name="pickup-lattitude2" placeholder="Type Your Location" value="<?php echo $homeLattitude ?>">
                            <input type="hidden" class="form-control" id="pickup-longittude2" name="pickup-longittude2" placeholder="Type Your Location" value="<?php echo $homeLongitude ?>">
                            <input type="hidden" class="form-control" id="selected_address_type" name="selected_address_type"  value="1">
                          </div>
                          
                        <div id="map2" style="height: 250px;"></div>
                        <button class="submit_btn" id="saveDynamicAddress" type="button"> 
                         CONFIRM LOCATION & PROCEED</button>
                     </div>
                    </div>
                   
            </div>
      </div>
       </form>
    </div>
  </div>
</div>
<style>
    .pac-container{
        z-index: 9999999999;;
    }
</style>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>frontend_assets/css/mdtimepicker.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>frontend_assets/css/zabuto_calendar.min.css"/>
 <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>frontend_assets/css/jquery-ui.theme.css"/>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
<!-- <script type="text/javascript" src="<?php echo base_url();?>frontend_assets/js/zabuto_calendar.min.js"></script> -->
<script type="text/javascript" src="<?php echo base_url();?>frontend_assets/js/zabuto_calendar.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>frontend_assets/js/toggle-script_new.js"></script>
 <script type="text/javascript" src='https://maps.google.com/maps/api/js?key=AIzaSyCHFZ49O5XuPD9RR-s0grdzBoV4wAZxJB8&libraries=places&sensor=false'></script>
 <script type="text/javascript" src="<?php echo base_url();?>frontend_assets/js/locationpicker.jquery.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>frontend_assets/js/mdtimepicker.min.js"></script>
  <!-- <script type="text/javascript" src="<?php echo base_url();?>frontend_assets/js/scrollSpeed.js"></script> -->
  <!-- <script type="text/javascript" src="<?php echo base_url();?>frontend_assets/js/scrollSpeedScript.js"></script> -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>frontend_assets/js/moment.js"></script>
<script>
  window.user_id               = "<?php echo  (int)$this->session->userdata('eq_user_id') ;?>";
  window.user_type             = "<?php echo  (int)$this->session->userdata('eq_user_type') ;?>";
  
    $(document).delegate(".btnCountinue","click",function(e)
    {
      //alert(window.user_id);
    //  alert(window.user_type);
       inputType               = $(this).attr("data-qtype");
       className              = "radio"+$(this).attr("data-current");
       selectedQuestion  =  $(this).attr("data-current");
      //user_id             = "<?php echo  $this->session->userdata('eq_user_id') ;?>";
     // user_type        = "<?php echo  $this->session->userdata('eq_user_type') ;?>";
      
      
      if(inputType ==4)
      {
            selectedAnswer     =  $("input:radio."+className+":checked").val();
      }
      else if(inputType ==5)
      {
           selectedAnswer     = $('.'+className+':checkbox:checked').val();
      }
      else
      {
           selectedAnswer     = $('#dynamicQues'+selectedQuestion).val();
      }
    
     
       offset                       =  $(this).attr("data-offset");
       last_parent                  =  $(this).attr("data-parent");
      // alert(last_parent);
       if(last_parent>0)
       {
           sessionStorage.removeItem("last_parent");
           sessionStorage.setItem("last_parent", last_parent);
       }
       else
       {
           last_parent = sessionStorage.getItem("last_parent");
       }
      // alert(offset);
       
       buttonId                  =  $(this).attr("id");
       is_home_category ='<?php echo $is_home_category ?>';
        
       if((selectedAnswer>0 || selectedAnswer!="" ) &&  typeof selectedAnswer !="undefined")
       {
           
                 var formData = new FormData($("#dynamicForm2")[0]);
                 csrf_value  =   getCookie('csrf_cookie_name');        
                 formData.append('<?php echo $this->security->get_csrf_token_name();?>',csrf_value);
                 formData.append('selectedAnswer',selectedAnswer);
                 formData.append('offset',offset);
                 formData.append('selectedQuestion',selectedQuestion);
                 formData.append('buttonId',buttonId);
                 formData.append('serviceTypeid',"<?php echo $_GET['sid'];?>");
                 formData.append('last_parent',last_parent);
             $.ajax({
             url: '<?php echo base_url();?>website/Request/checkValidation',
             type: 'POST',
             data: formData,
             async: true,
             success: function (data) 
                {
                  lastQuestion =  $(".lastQue:last-child").val();
                  
                 /*  if(is_home_category==1)
                         {
                         $("#backFromRemark").attr("data-current",selectedQuestion);
                         }
                         else
                         {
                             $("#backFromValidity").attr("data-current",selectedQuestion);
                             
                         }*/
                     $("#backFromRemark").attr("data-current",selectedQuestion);
                   if(data!="")
                   {
                       dat =data.split("^");
                         data =dat[1];
                         $(".parent"+selectedQuestion).remove();
                         $(".commonDisplayQuestion").css("display","none");
                         $("#span"+dat[0]).remove();
                         $(data).insertAfter("#span"+selectedQuestion);
                         
                         
                        // alert(sessionStorage.getItem("dynamicQues53"));
                         
                          populateOldData();
                          //alert($(".lastQue:last-child").val());
                          
                   }
                   else
                   {
                        $(".commonDisplayQuestion").css("display","none");
                            $("#Upload_section").css("display","block");
                     /* if(is_home_category==1)
                      {
                            $(".commonDisplayQuestion").css("display","none");
                            $("#Upload_section").css("display","block");
                            
                      }
                      else
                      {
                             goToLocationTab();
                      }*/
                   }
               },
             cache: false,
             contentType: false,
             processData: false
         });
         }
         else
         {
            // $("#questionError").css("display","block")
            // $("#questionError").html("select any answer");
            // myFunctionTiming("#questionError");
            swal("Please answer the question");
         }
    });
    function myFunctionTiming(inputElement) {
  setTimeout(function(){ $(inputElement).css("display","none") }, 3000);
}
     $(document).delegate(".back","click",function(e)
    {
           selectedQuestion  =  $(this).attr("data-current");
           $(".commonDisplayQuestion").css("display","none");
           $(".questionArea").css("display","block");
           $(".locationPan").css("display","none");
           $("#span"+selectedQuestion).css("display","block");
           $("#Upload_section").css("display","none");
           populateOldData();
           
    });
       $(document).delegate("#fileUploadNext","click",function(e)
     {
         fileName     = $('#filestyle-0').val();
         discription = $('#txtRemark').val();
         $("#filepath").val(fileName);
         error=0;
        if(discription=="")
        {
            $('#txtRemark').css("border-color","red");
              error=1;
        }
        else
        {
            $('#txtRemark').css("border-color","");
        }
        if(fileName=="")
        {
            $("#filepath").css("border-color","red");
             error=1;
        }
        else
        {
             $("#filepath").css("border-color","");
        }
        
        if(error==0)
              goToLocationTab();
              
     });
       $(document).delegate("#btnLocationNext","click",function(e)
     {

           error=0; 
           is_home_category ='<?php echo $is_home_category ?>';
           vdate = $("#my-calendar").data("date");
           var valdate = $("#service_date").val();
           var valTime  =  $(".badge-pill.active").html();
           if(valdate=="")
           {
               
                 swal("Please select job validity period");
                 $("#datetimepicker4").css("border-color","red");
                 error=1;
                 return false;
           }
           else
           {
                $("#datetimepicker4").css("border-color","");
           }
             if(valTime=="")
           {
                swal("Please select job validity time");
                 $("#datetimepicker3").css("border-color","red");
                 error=1;
                 return false;
           }
           else
           {
                 $("#datetimepicker3").css("border-color","");
           }
           
           if(is_home_category==1 && $("#us5-street1").val()=="")
           {
                error=1;
               $("#us5-street1").css("border-color","red");
           }
           else
           {
                $("#us5-street1").css("border-color","");
           }
          if(is_home_category==1 && $("#us5-city").val()=="")
           {
                error=1;
               $("#us5-city").css("border-color","red");
           }
           else
           {
                $("#us5-city").css("border-color","");
           }
            if(is_home_category==1 && $("#us5-state").val()=="")
           {
                error=1;
               $("#us5-state").css("border-color","red");
           }
           else
           {
                $("#us5-state").css("border-color","");
           }
           
          if(error==0)
          {
           
              if(is_home_category==1)
              {
               goToSelectOption();
              }
              else
              {
                   var addressType  =  $(".location_button.active").attr("for");
                   var valdate            = $("#datetimepicker4").val();
                   var  service_date  =  $('#service_date').val();
                   
                  
                  formated =  moment(valdate).format("YYYY-MM-DD");
                 // alert(valdate);
                 // alert(formated);
                  //var d1 = new Date(formated);
                 // var d2 = new Date(valdate);
                /*  
                  if(d1>d2)
                  {
                      alert("s");
                  }
                 */
                 var valTime         =  $("#service_date").val();
                 var serviceTime     =  $(".badge-pill.active").html();
                 d2 = formated+" "+valTime;
                 d1 = service_date+" "+serviceTime;
                 //alert(d2);
                 var today = new Date();
var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
var dateTime = date+' '+time;
                 var beginningTime = moment(d2, 'YYYY-MM-DD h:mma');
                 var endTime = moment(dateTime, 'YYYY-MM-DD h:mma');
                // alert(beginningTime);
                //  alert(endTime);
                 // alert(dateTime);
                // alert(endTime);
                 // if(beginningTime.isBefore(endTime)==true)
                 //    {
                 //         swal("Validity date should be greater than  current time");
                 //         return false;
                 //    }
                    
                   // alert("ser-"+service_date);
                   // alert("val-"+formated);
                   // alert("<?php echo date('Y-m-d h:i A'); ?>");
                  var beginningTime3 = moment(d2, 'YYYY-MM-DD h:mma');
                 var endTime3 = moment(d1, 'YYYY-MM-DD h:mma');
                 //  if(beginningTime3.isBefore(endTime3)==false)
                 // {
                 //     swal("Validity date should not exceed service date");
                 //     return false;
                 // }
                 if(service_date==formated)
                 {
                   
                  // var today = new Date();
                   //var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
                   //alert(date);
                   // var d1 = date+" "+serviceTime;
                    //var d2 = date+" "+valTime;
                    //var aDate = Date.parse(d1);
                    //var bDate = Date.parse(d2);

                   // alert(d1);
                   // alert(d2);
                  //  alert(aDate);
                  //  alert(bDate);
                  var beginningTime2 = moment(serviceTime, 'h:mma');
                  var endTime2 = moment(valTime, 'h:mma');
                //alert(beginningTime.isBefore(endTime));
                    if(beginningTime2.isBefore(endTime2)==true)
                    {
                         swal("Validity date/time should not exceed service date/time");
                         return false;
                    }
                 }
                   //alert(service_date);
                    // alert(formated);
                   // if(addressType == 1)
                   // {
                   //             swal({
                   //        title: "Are you sure to proceed with home address?",
                   //        text: "",
                   //        icon: "warning",
                   //        buttons: true,
                   //        dangerMode: true,
                   //      })
                   //      .then((willDelete) => {
                   //        if (willDelete) 
                   //        { 
                          
                   //         goToSelectOption();
                           
                   //        } else 
                   //        {
                              
                           
                   //        }
                   //      });
                   // }
                   // else
                   // {
                        goToSelectOption();
                   //}
                  
                  
                                 
              }
          }
             
              
     });

      $(document).delegate("#btnPaymentNext","click",function(e)
     {
      
        if($("input:radio.paymentOptionChoose:checked").length == 1) {
          $('.paymentOption').hide();
          $('.summarySection').show();
          $('#paymentOptionChoosed').val($("input:radio.paymentOptionChoose:checked").val());
          var paymentOptionChoosed = $("#paymentOptionChoosed").val();
          var addressType  =  $(".location_button.active").attr("for");
          var serviceLocation = $("#serviceLocation").val();
          var valdate = $("#service_date").val();
          var valTime  =  $(".badge-pill.active").html();
          debugger
          d = new Date(valdate);
          var day = d.getDate();
          var year = d.getFullYear();
          var month = d.toLocaleString('default', { month: 'short' });
          valDate = day+' '+month+' '+year;
          if(paymentOptionChoosed == 1) {
            paymentOptionText = 'Cash On Delivery';
          }
          if(paymentOptionChoosed == 2) {
            paymentOptionText = 'Debit/Credit Card Payment';
          }
          if(addressType==1)
          {
             addressTypeLabel = 'Home';
          }
          else if(addressType==2)
          {
             addressTypeLabel = 'Office';
          }
          else
          {
             addressTypeLabel = 'Other';
          }
          $('#service_summary_datetime').text(valDate+' '+valTime);
          $('#service_summary_address').text(serviceLocation);
          $('#service_summary_payment_option').text(paymentOptionText);
          $('#service_summary_location_type').text(addressTypeLabel);
           debugger
        } else {
          swal("Please choose payment option");
          return false;
        }
     });
      $(document).delegate("#backfromSummarySection","click",function(e)
     {
        $(".questionArea").css("display","none");
        $(".locationPan").css("display","none");
        $('.paymentOption').show();
        $('.summarySection').hide();
     });
         $(document).delegate("#filestyle-0","change",function(e)
     {
         fileName     = $('#filestyle-0').val();        
         $("#filepath").val(fileName);
 });
    
    $(document).delegate("#btnBookNow","click",function(e) {
      saveRequest(2);
    });

     $(document).delegate(".selectOptions","click",function(e)
     {
          sessionStorage.setItem("lastAction", "question");
                  if(window.user_id<=0)
              {
                   $("#exampleModal").modal("show");
                   return false;
              }
              else  if(window.user_type!=1)
              {
                  swal("Please login as an user");
                  return false;
              }
              var option              =  $(this).attr("for");
              
              if(option==1)
              {
                   saveRequest(1);
              }
              else if(option==2)
              {
                    $(".providers_wrap").css("display","block"); 
                    $(".selectOptionSub").css("display","none");
                    getProviders();
                    return false;
              }
              else
              {
                  swal("Invalid section");
              }
              
           
             
          
   });

   function saveRequest(option)
   {
      // alert(option);
       sessionStorage.setItem("lastAction", "question");
     
    // alert(window.user_type);
      if(window.user_id<=0)
      {
           $("#exampleModal").modal("show");
           return false;
      }
      else  if(window.user_type!=1)
      {
          swal("Please login as an user");
          return false;
      }
       
              var serviceAddress = $('#serviceAddress').val();
              serviceAddress = JSON.parse(serviceAddress);

              debugger
               var valdate            = $('#service_date').val();
               var valTime            = $(".badge-pill.active").html();
               var street               =  serviceAddress.user_adresses_location
;
               var city                    =  $("#us5-city").val();
               var state                 =  $("#us5-state").val();             
               var  discription      =  $('#txtRemark').val();
               var  service_date  =  $('#service_date').val();
               var serviceTime     =  $(".badge-pill.active").html();
               var price_from       = $("#price_from").html();
               var price_to            = $("#price_to").html();
               var serviceTotPricePass            = $("#serviceTotPricePass").val();
               
               var addressType  =  $(".location_button.active").attr("for"); 
               var lattitude         =  serviceAddress.user_adresses_lattitude
; 
               var longitude       =  serviceAddress.user_adresses_longitude
; 
              // alert(price_from);
               
              // var  file_data = $('#filestyle-0').get(0).files[0];
              var  is_home_category ='<?php echo $is_home_category ?>'; 
               var formData = new FormData($("#dynamicForm")[0]);
                i=0;		   
	$('.custom-file-input').each(function() 
	{
         //  alert();                             
		 file_data = $('.custom-file-input').get(i).files[0];
       formData.append('document[]',file_data);
		i++;
	});	
              
               
               
  //              if(option==2)
  //              {
  //                   mappedItems =    $( ".providerSelectDiv > .selected" )
  // .map(function() {
  //   return $(this).attr("for");
  // })
  // .get()
  // .join();
  
  //          if(mappedItems=="")
		//    {
		// 	   swal("Select atleast one provider");
			   
		// 	   return false;
		//    }
  //              }
  //              else
  //              {
                   mappedItems="";
               //}
               
               csrf_value     =   getCookie('csrf_cookie_name');        
               formData.append('<?php echo $this->security->get_csrf_token_name();?>',csrf_value);
               formData.append('option',option);
               formData.append('valdate',valdate);
               formData.append('valTime',valTime);
               formData.append('street',street);
               formData.append('city',city);
               formData.append('state',state);
               formData.append('discription',discription);
               
               formData.append('is_home_category',is_home_category);
               formData.append('is_home_category',is_home_category);
               formData.append('service_date',service_date);
               formData.append('serviceTime',serviceTime);
               formData.append('price_from',price_from);
               formData.append('price_to',price_to);
               formData.append('addressType',addressType);
               formData.append('lattitude',lattitude);
               formData.append('longitude',longitude);
               formData.append('serviceTotPricePass',serviceTotPricePass);
               formData.append('service_type_id',<?php echo $this->common_functions->decryptId($_GET['sid']);?>);
               formData.append('mappedItems',mappedItems);
                     $.ajax({
             url: '<?php echo base_url();?>website/Request/saveRequest',
             type: 'POST',
             data: formData,
             async: true,
             success: function (data) 
                {
                    
                   if(data>0)
                   {
                        goToSuccesspage(option);
                   }
                   // else if(data==-1)
                   // {
                   //     swal("Please update your address");
                   //     $("#loactionUpdate").modal("show");
                   //     $("#selected_address_type").val(addressType);
                   //     if(addressType==1)
                   //     {
                   //         $("#addressTypeLabel").text("Home");
                   //     }
                   //     else if(addressType==2)
                   //     {
                   //         $("#addressTypeLabel").text("Office");
                   //     }
                   //     else
                   //     {
                   //         $("#addressTypeLabel").text("Other");
                   //     }
                   //     return false;
                   // }
                },
             cache: false,
             contentType: false,
             processData: false
         });
          
   }
     function goToLocationTab()
     {
            // sessionStorage.clear();
             $currElement= $("#locationPan");
             $(".bullet").removeClass('bullet_solid');
             $(".pan").css("background", "");
             $currElement.css('background-color', '#d52d2f');
             $currElement.addClass('bullet_solid');
             $(".first-bullet").css("background-color", "#cacaca");
             $(".pageWrapp").css("display","none");
             $(".locationPan").css("display","block");
     }
     function goToSelectOption()
     {
            $(".providers_wrap").css("display","none"); 
           $(".selectOptionSub").css("display","-webkit-box");
            // $("#divProvider").html("");
             //added 20-06-2019       
                    
                    
             $currElement= $("#selectOption");
             $(".bullet").removeClass('bullet_solid');
             $(".pan").css("background", "");
             $currElement.css('background-color', '#d52d2f');
             $currElement.addClass('bullet_solid');
             $(".first-bullet").css("background-color", "#cacaca");
             $('#loginAsRequest').val(1)
             $('#registerAsRequest').val(1)
             //$(".pageWrapp").css("display","none");
             
              sessionStorage.setItem("lastAction", "question");
              if(window.user_id<=0)
              {
                   $("#exampleModal").modal("show");
                   return false;
              }
              else  if(window.user_type!=1)
              {
                  swal("Please login as an user");
                  return false;
              }
                        var addressType  =  $(".location_button.active").attr("for"); 

             // swal("Please update your address");
               $("#loactionUpdate").modal("show");
               $("#selected_address_type").val(addressType);
               if(addressType==1)
               {
                   $("#addressTypeLabel").text("Home");
               }
               else if(addressType==2)
               {
                   $("#addressTypeLabel").text("Office");
               }
               else
               {
                   $("#addressTypeLabel").text("Other");
               }

     }
       function goToSuccesspage(option)
     {
             sessionStorage.clear();
             $currElement= $("#page-succes");
             $(".bullet").removeClass('bullet_solid');
             $(".pan").css("background", "");
             $currElement.css('background-color', '#d52d2f');
             $currElement.addClass('bullet_solid');
             $(".first-bullet").css("background-color", "#cacaca");
             $(".pageWrapp").css("display","none");
             $(".page-succes").css("display","block");
             if(option==1)
             {
                 $(".text-white").html("Thank You For Submiting Enquiry");
                 $(".text-white_sub").html("You will Receive Quotation Soon");
             }
              if(option==2)
             {
                 $(".text-white").html("Thank You For Submiting Service Request");
                 $(".text-white-sub").html("You will get the reply soon");
             }
     }
     function goToFileUploadPage()
     {
         //alert();questionArea
            $currElement= $(".questionArea");
             $(".bullet").removeClass('bullet_solid');
             $(".pan").css("background", "");
             //$currElement.css('background-color', '#d52d2f');
            // $currElement.addClass('bullet_solid');
             $(".first-bullet").css("background-color", "#d52d2f");
            // $(".pageWrapp").css("display","block");
            $(".questionArea").css("display","block");
                            $(".locationPan").css("display","none");
                            $("#Upload_section").css("display","block");
                         //   alert(2);
     }
     
     
     
      $(document).delegate("#homeSettingsBack,#backFromValidity","click",function(e)
    {
         goToFileUploadPage();
     });
      $(document).delegate("#backFromProviderSelection","click",function(e)
    {
         goToSelectOption();
     });
     
      $(document).delegate("#backFromSelectOption,#backfromPaymentOption","click",function(e)
    {
         goToLocationTab();
     });
     
     
    var validator=$("#dynamicForm").validate(
            //alert();
        {
           ignore: [],
        rules: 
        {
          
         
          'question[]':
                  {
                      required: true
                  }
          
		  
        },
        messages: 
        {
       
    },
    
    errorPlacement: function(error, element) {
        alert();
      var placement = $(element).data('error');
      if (placement) {
        $(placement).append(error)
      } else {
        error.insertAfter(element);
      }
        $(".form-errors").html("All fields must be completed before you submit the form.");
    },
   
//     showErrors: function(errorMap, errorList) {
//        $(".form-errors").html("All fields must be completed before you submit the form.");
//    },
     submitHandler: function ()
        {
			
             
                dataString = $('#dynamicForm').serialize();
                var formData = new FormData($("#dynamicForm")[0]);
                csrf_value  =   getCookie('csrf_cookie_name');        
                formData.append('<?php echo $this->security->get_csrf_token_name();?>',csrf_value);
                
                     $.ajax({
             url: '<?php echo base_url();?>website/Request/checkValidation',
             type: 'POST',
             data: formData,
             async: true,
             success: function (data) 
                {
                   if(data==1)
                   {
                      alert(1); 
                   }
                   else
                   {
                       alert(2); 
                   }
               },
             cache: false,
             contentType: false,
             processData: false
         });

                     return false;
      
        
                }
       
 });  
 
 
    $(function () {
            $( "#datetimepicker3" ).mdtimepicker();

            $( "#datetimepicker4" ).datepicker({
              showOtherMonths: true,
              selectOtherMonths: true,
              dateFormat: 'd M yy',
               minDate: 0
            });
//                $('#datetimepicker4').datetimepicker({
//                    format: 'L'
//                });
//                $('#datetimepicker3').datepicker();
            });
    $("#my-calendar").zabuto_calendar({
            today: true,
            show_previous: false,
            action: function () {
                return myDateFunction(this.id, false);
            },
            nav_icon: {
              prev: '<i class="fa fa-chevron-left"></i>',
              next: '<i class="fa fa-chevron-right"></i>'
            },
        });
        function myDateFunction(id, fromModal) {
            var date = $("#" + id).data("date");
            $("#service_date").val(date);
            //alert(date);
            var hasEvent = $("#" + id).data("hasEvent");
//            alert('You clicked on date ' + date);
            $("div.day").removeClass('today');
            $("#" + id + "> div").addClass('today');
//            $("#date-popover-content").html('You clicked on date ' + date);
            return true;
        }
       
//    $('div.day').on('click', function(){
//    $('div.day').click(function(){
//        //    $('div.day').removeClass('today');
//        //    $(this).addClass('today');
//        alert('Worsndhcvg');
//    });

 $(document).ready(function(){
          $('.search button').click(function(){
              $('.search-box').addClass('search-box-add');
          });
          $('.close_button').click(function(){
              $('.search-box').removeClass('search-box-add');
          });
          
          
          $('.min-search button').click(function(){
              $('.search-box').addClass('search-box-add');
          });
          
          function updateControls(addressComponents) {
              
             // alert();
              console.log(addressComponents);
                $('#us5-street1').val(addressComponents.addressLine1);
                $('#us5-city').val(addressComponents.city);
              //  $('#us5-state').val(addressComponents.stateOrProvince);
              $('#us5-state').val(addressComponents.country);
                $('#us5-zip').val(addressComponents.postalCode);
                $('#us5-country').val(addressComponents.country);
                
                
            }
         
                             var lat = 25.204849;
                              lng = 55.270782;
                              
                             var myLatLng = {lat: '<?php echo $defaultLattittude;?>', lng: '<?php echo $defaultlongittude;?>'};
                              var myLatLng = {lat: 25.204849, lng: 55.270782};
                             image = '<?php echo base_url();?>frontend_assets/images/icons/map_pin.png';
                             var MAP1 = new google.maps.Map(document.getElementById('MAP1'), {
                              zoom: 10,
                              disableDefaultUI: true,
                              center: myLatLng
                            });
                        latlng = new google.maps.LatLng(lat, lng);     
                      marker = new google.maps.Marker({
            position: latlng,
            map: MAP1,
            draggable: true,
            animation: google.maps.Animation.DROP,
           // icon: image
         });      
         
         var input = document.getElementById('us5-street1'); 
         
           var autocomplete = new google.maps.places.Autocomplete(input, {
        types: ["geocode"]
    });                        
        autocomplete.bindTo('bounds', MAP1); 
        
         var infowindow = new google.maps.InfoWindow(); 
     google.maps.event.addListener(autocomplete, 'place_changed', function() {
        var place = autocomplete.getPlace();
        console.log(place);
       //results[0]= place;
         if (place.geometry.viewport) {
            MAP1.fitBounds(place.geometry.viewport);
        } else {
            MAP1.setCenter(place.geometry.location);
            MAP1.setZoom(17);
        }
         latlng = new google.maps.LatLng(place.geometry.location.lat(), place.geometry.location.lng());
        //moveMarker(place.name, place.geometry.location);
        moveMarker(marker, latlng);
        document.getElementById("us2-lat").value=place.geometry.location.lng();
	    document.getElementById("us2-lon").value=place.geometry.location.lat();
	     $('#us5-street1').val(place['address_components'][0].long_name);
                     $('#us5-city').val(place['address_components'][1].long_name!=""?place['address_components'][1].long_name:place['address_components'][1].long_name);
                     $('#us5-state').val(place['address_components'][2].long_name!=""?place['address_components'][2].long_name:place['address_components'][2].long_name);
                   
       
    });
        google.maps.event.addListener(marker, 'dragend', function() {
          //alert();
          var infowindow = new google.maps.InfoWindow(); 
    var geocoder = new google.maps.Geocoder();

        geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
           
            if (status == google.maps.GeocoderStatus.OK) 
            {
                if (results[0]) 
                {
                    //console.log(results[0]);
                    
                    //alert();
                  
                     $('#us5-street1').val(results[0]['address_components'][0].long_name);
                     $('#us5-city').val(results[0]['address_components'][1].long_name!=""?results[0]['address_components'][1].long_name:results[0]['address_components'][1].long_name);
                     $('#us5-state').val(results[0]['address_components'][2].long_name!=""?results[0]['address_components'][2].long_name:results[0]['address_components'][2].long_name);
                     $('#us2-lat').val(marker.getPosition().lng());
                     $('#us2-lon').val(marker.getPosition().lat());
                    
                    
                    
                    //infowindow.setContent(results[0].formatted_address);
                    
                    
                    
                       //  infowindow.open(map, marker);
                    //infoWindow.close();
                    //map.setCenter(marker.getPosition());
                    //ShowNext();
                }
            }
        });
    });  
        
          /*  $('#MAP1').locationpicker({
                location: {
                    latitude: '<?php echo $defaultLattittude;?>',
                    longitude: '<?php echo $defaultlongittude;?>'
                },
                radius: 400,
                 inputBinding: {
            latitudeInput: $('#us2-lat'),
            longitudeInput: $('#us2-lon'),
         
        },
                onchanged: function (currentLocation, radius, isMarkerDropped) {
                    var addressComponents = $(this).locationpicker('map').location.addressComponents;
                    updateControls(addressComponents);
                },
                oninitialized: function (component) {
                    var addressComponents = $(component).locationpicker('map').location.addressComponents;
                    //var place = $(component).locationpicker('map').location.getPlace();
                    //console.log($(component).locationpicker('map').location);
                   //console.log(place);
                   // updateControls(addressComponents);
                     $('#us5-street1').val('<?php echo $defaultLocation;?>');
                     $('#us5-city').val('<?php echo $defaultCity;?>');
                     $('#us5-state').val('<?php echo $defaultState;?>');
                     $('#us2-lat').val('<?php echo $defaultLattittude;?>');
                     $('#us2-lon').val('<?php echo $defaultlongittude;?>');
                }
            });*/
          
          
      });
      var map;
      function initialize() {

    //var acInputs = document.getElementsByClassName("autocomplete");
    
    var input = document.getElementById('us5-street1');
    
   // alert(acInputs.length);
    
     var autocomplete = new google.maps.places.Autocomplete(input);
       // autocomplete.inputId = acInputs[i].id;

        google.maps.event.addListener(autocomplete, 'place_changed', function () {
           // alert();
			
           // document.getElementById("log").innerHTML = 'You used input with id ' + this.inputId;
			var place = autocomplete.getPlace();
			
			 //console.log(place);
			 
			  
                $('#us5-city').val("Dubai");
                $('#us5-state').val("Dubai");
                $('#us2-lat').val(25.204849);
                $('#us2-lon').val(55.270782);
                
             /*  var myLatlng = new google.maps.LatLng(place.geometry.location.lat(), place.geometry.location.lng());
        marker = new google.maps.Marker({
            position: myLatlng,
            map: MAP1,
            title: ""
        }); 
                
                */
                
		//	alert(place.name+place.geometry.location.lat()+place.geometry.location.lng());
			
        });

   /* for (var i = 0; i < acInputs.length; i++) {
		j=i+1;
		

        var autocomplete = new google.maps.places.Autocomplete(acInputs[i]);
        autocomplete.inputId = acInputs[i].id;

        google.maps.event.addListener(autocomplete, 'place_changed', function () {
			
           // document.getElementById("log").innerHTML = 'You used input with id ' + this.inputId;
			var place = autocomplete.getPlace();
			//alert(place.name+place.geometry.location.lat()+place.geometry.location.lng());
			
			document.getElementById("longi"+j).value=place.geometry.location.lng();
			document.getElementById("latti"+j).value=place.geometry.location.lat();
           
        });
    }*/
    var homeLat = 25.0711436;
       homeLong = 55.2440753;
     
         var iconBase = '<?php echo base_url();?>frontend_assets/images/icons/map-pin.png';
        latlng  = new google.maps.LatLng(homeLat, homeLong);
     map2 = new google.maps.Map(document.getElementById('map2'), {
                              center: new google.maps.LatLng(homeLat, homeLong),           
            zoom: 15,           
            disableDefaultUI: true,
            scaleControl: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP  
                            });  
                             marker2 = new google.maps.Marker({
            position: latlng,
            map: map2,
            draggable: true,
            animation: google.maps.Animation.DROP,
            icon: iconBase
         }); 
         infowindow = null;
        var input2 = document.getElementById('pickup-input2'); 
         var autocomplete2 = new google.maps.places.Autocomplete(input2, {
        types: ["geocode"]
    });  
    autocomplete2.bindTo('bounds', map2);
      google.maps.event.addListener(autocomplete2, 'place_changed', function() {
        //  alert();
        //infowindow.close();
        var place = autocomplete2.getPlace();
         if (place.geometry.viewport) {
            map2.fitBounds(place.geometry.viewport);
        } else {
            map2.setCenter(place.geometry.location);
            map2.setZoom(17);
        }
         latlng = new google.maps.LatLng(place.geometry.location.lat(), place.geometry.location.lng());
        //moveMarker(place.name, place.geometry.location);
        moveMarker(marker2, latlng);
        document.getElementById("pickup-longittude2").value=place.geometry.location.lng();
	    document.getElementById("pickup-lattitude2").value=place.geometry.location.lat();
	    
    }); 
     google.maps.event.addListener(marker2, 'dragend', function() {
          //alert();
         // var infowindow = new google.maps.InfoWindow(); 
    var geocoder = new google.maps.Geocoder();

        geocoder.geocode({'latLng': marker2.getPosition()}, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    $('#pickup-input2').val(results[0].formatted_address);
                   $('#pickup-lattitude2').val(marker2.getPosition().lat());
                    $('#pickup-longittude2').val(marker2.getPosition().lng());
                    infowindow.setContent(results[0].formatted_address);
//                    infowindow.open(map, marker);
                    infoWindow.close();
                    map.setCenter(marker2.getPosition());
                    ShowNext();
                }
            }
        });
    });
         
}
 function moveMarker(markerName, latlng) 
            {
                infowindow = null;
        markerName.setIcon(null);
        markerName.setPosition(latlng);
       // infowindow.setContent(placeName);
    }
initialize();
      function getProviders()
      {
          
          csrf_value  =   getCookie('csrf_cookie_name');    
          var lattitude         =  $("#us2-lat").val(); 
          var longitude       =  $("#us2-lon").val(); 
          var txt_keyword       =  $("#txt_keyword").val(); 
          var txt_rating       =  $("#txt_rating").val(); 
          var txt_distance       =  $("#txt_distance").val(); 
          
          var addressType  =  $(".location_button.active").attr("for"); 
             
              // alert(price_from);
               
              // var  file_data = $('#filestyle-0').get(0).files[0];
              var  is_home_category ='<?php echo $is_home_category ?>'; 
          
          $("#divProvider").html("<img src='<?php echo base_url();?>frontend_assets/images/loader-new.gif'  style='    float: none;position:absolute; top: 42px;left: 32%; width: 110px;height: 76px;'>");
         //alert(lattitude);
        // return false;
          $.ajax({
            url: '<?php echo base_url();?>website/Request/getProviders',
            type: 'POST',
            data: {is_home_category:is_home_category,addressType:addressType,txt_keyword:txt_keyword,txt_rating:txt_rating,txt_distance:txt_distance,lattitude:lattitude,longitude:longitude,'service_type_id':'<?php echo $this->common_functions->decryptId($_GET["sid"]);?>','<?php echo $this->security->get_csrf_token_name();?>':csrf_value},
            success: function (data) 
			 {  
			      $("#divProvider").html("");
                                                                                
			 	 if(data==0)
                                                                                  {  
                                                                                     swal("Something went wrong");   
                                                                                      
                                                                                  }                                                                                  
			 	else if(data==-1)
                                                                                  {  
                                                                                     swal("Validation error");   
                                                                                      
                                                                                  }
                                                                                  else
                                                                                  {
                                                                                     $(".providers_wrap").css("display","block"); 
                                                                                     $(".selectOptionSub").css("display","none");  
				                                                                    $("#divProvider").html(data);
                                                                                    loadRatingLoop2();
                                                                                  }
				
                                                                 }
        });
          
      }
      $(document).delegate(".search_btn","click",function(e)
    {
         getProviders();
     });
 
    $(function ()
    {
     loadRating();
      $(".rateYo3").rateYo({
        rating: 3.5,
        readOnly: true,
        starWidth: "15px",
        normalFill: "#e0e0e0",
        ratedFill: "#ed6329"
      });
  
    });
function loadRating()
{
//     $(".rateYo").rateYo({
//        rating: 4.5,
//        readOnly: true,
//        starWidth: "15px",
//        normalFill: "#e0e0e0",
//        ratedFill: "#fac917"
//      });
      $(".rateYo1").rateYo({
        rating: 0,
        starWidth: "25px",
        normalFill: "#e0e0e0",
        ratedFill: "#fac917"
      }).on("rateyo.change", function (e, data) {
                var rating = data.rating;
                $(this).find(".rateval").remove();
                $(this).append("<span class='rateval'>"+rating+"</span>");
              });
 }
   $(document).delegate(".providerDetails","click",function(e)
    {
        
              var providerId         =   $(this).attr("for"); 
              getProviderDetails(providerId);
        
     });
     function getProviderDetails(providerId)
     {
              csrf_value                 =   getCookie('csrf_cookie_name');    
      
         
          $.ajax({
            url: '<?php echo base_url();?>website/Request/getProviderDetails',
            type: 'POST',
            data: {providerId:providerId,'<?php echo $this->security->get_csrf_token_name();?>':csrf_value},
            success: function (data) 
			  {           
                  $("#exampleModalCenter").modal("show");
                  $("#detailDiv").html(data);
                  loadRating();
                  loadRatingLoop();
             }
        });
     }
     function loadRatingLoop()
     {
         $('.rateYoLoop').each(function() {
        rating = $(this).attr("data-rating");
  $(this).rateYo({
   
    rating: rating,
     readOnly: true,
        starWidth: "15px",
        normalFill: "#e0e0e0",
        ratedFill: "#fac917"
  });
});
     }
 function loadRatingLoop2()
     {
         $('.rateYoLoop2').each(function() {
        rating = $(this).attr("data-rating");
  $(this).rateYo({
   
    rating: rating,
     readOnly: true,
        starWidth: "15px",
        normalFill: "#e0e0e0",
        ratedFill: "#fac917"
  });
});

     }
     
       $(document).delegate("#btnAddRating","click",function(e)
    {
           var user_id = '<?php echo $this->session->userdata("eq_user_id");?>';
           if(user_id<=0)
           {
               $("#exampleModal").modal("show");
           }
            var txt_feedback = $("#txt_feedback").val();
            var rateval  = $(".rateval").text();
            var providerId  = $("#txt_provider").val();
          //  alert(rateval);
        
            error=0;
            if(txt_feedback=="")
            {
                $("#error_txt_feedback").html("Enter a feedback");
                error=1;
            }
            else
            {
                $("#error_txt_feedback").html("");
            }
               if(rateval<=0)
            {
                $("#error_txt_rating").html("Select a rating");
                error=1;
            }
            else
            {
                $("#error_txt_rating").html("");
            }
            
            if(error==0)
            {
                  csrf_value                 =   getCookie('csrf_cookie_name');   
                  $.ajax({
            url: '<?php echo base_url();?>website/Request/addRating',
            type: 'POST',
            data: {txt_feedback:txt_feedback,rateval:rateval,providerId:providerId,'<?php echo $this->security->get_csrf_token_name();?>':csrf_value},
            success: function (data) 
			  {       
                                                                         data =  jQuery.parseJSON(data);
                                                                        
                                                                          if(data['status']==1)
                                                                            {
                                                                                  $(".error").html("");// clear all errors
                                                                                   getProviderDetails(providerId);
                                                                             }
                                                                             else if(data['status']==3)
                                                                             {
                                                                                 $("#exampleModalCenter").modal("hide"); 
                                                                                 swal("You already rated this product");
                                                                             }
                                                                             else
                                                                             {
                                                                                 $("#exampleModalCenter").modal("hide"); 
                                                                                   swal("Something went wrong, try again later");
                                                                             }
                                                                 }
        });
            }
     });
     $(document).delegate(".select_button","click",function(e)
    {
        
      if ( $(this).hasClass("selected") ) 
                     {
	     $(this).removeClass("selected");
                          $(this).text("Select");
	}
                    else
                    {
                         $(this).addClass("selected");	
                          $(this).text("Selected");
                    }
        
     });
    
    $(document).delegate("#select_button_detail","click",function(e)
    {
                attrFor  =  $(this).attr("for");
               btn18
        
      if ( $(this).hasClass("selected") ) 
                     {
	     $(this).removeClass("selected");
                          $(this).text("Select");
                          $("#btn"+attrFor).removeClass("selected");
                          $("#btn"+attrFor).text("Select");
	}
                    else
                    {
                         $(this).addClass("selected");	
                          $(this).text("Selected");
                          $("#btn"+attrFor).addClass("selected");
                          $("#btn"+attrFor).text("Selected");
                    }
        
     });
      $(document).delegate("#select_provider","click",function(e)
     {
                     saveRequest(2);
     });
     
     $(function () {

      	function AppFunction(){
      	    
      	    var n = $( ".custom-file-input" ).length;
      	    if(n<=4)
      	    {
      	    nextVal = n+1;
      		$('.bootstrap-filestyle:last').after('<div class="bootstrap-filestyle input-group"><div class="custom-file"><input type="file" class="custom-file-input" id="customFile'+nextVal+'"><label class="custom-file-label" for="customFile'+nextVal+'" id="labelcustomFile'+nextVal+'">Upload Your File</label><span class="buttonText"><i class="fa fa-plus"></i></span></div><span class="group-span-filestyle input-group-btn Remove_btn" tabindex="0"><label for="filestyle-0" class="btn btn-default "><span class="icon-span-filestyle glyphicon glyphicon-folder-open"></span> <span class="buttonText"><i class="fa fa-minus"></i></span></label></span><span class="fileUplaodWarning instruction">Max upload size:20MB, (pdf,doc,jpg,jpeg,png)</span></div>');
      	   
      	    }
      	        
      	    };

          $('.AddRow').on('click', function(){
              	// alert(5255)
              	AppFunction();
           });

          $(document).on("click", ".Remove_btn" , function() {
	          $(this).parents(".bootstrap-filestyle").remove();
	       });

        });
        
          $(document).delegate(".custom-file-input","change",function(e)
     {
         id = $(this).attr("id");
         fileName     = $(this).val();    
        // alert(fileName);
        $("#label"+id).html(fileName);
   });
/*function appendHtmlValue()
  {
      
       scheduleDate = $("#datetimepicker4").val();
        scheduleTime = $("#datetimepicker3").val(); 
 var selectedSummary= "<ul>";
 $('.answerRadios:checked').each(function() {
 
   selectedSummary+="<li>"+$(this).attr("data-text")+"</li>";
});
$('.dynamicQues option:selected').each(function() {
 
   selectedSummary+="<li>"+$(this).html()+"</li>";
});

$('textarea.dynamicQues').each(function() {
 
   selectedSummary+="<li>"+$(this).val()+"</li>";
});
$('input.dynamicQues[type="text"]').each(function() {
 
   selectedSummary+="<li>"+$(this).val()+"</li>";
});
 //var selectedText = $(".dynamicQues option:selected").html();
//alert(selectedText);
if(scheduleDate!="")
    {
    selectedSummary+='<li> <b>Schedule</b> <span class="Adddate">'+scheduleDate+'</span> <span class="Addtime">'+scheduleTime+'</span></li>';
    }
 //selectedSummary+='<li> <b>Schedule</b> <span class="Adddate">29 May 2019</span> <span class="Addtime">6:45 PM</span></li>';
selectedSummary+="</ul>";
$(".spanSummery").html(selectedSummary);
    }*/
    
     $(document).delegate(".answerRadios","click",function(e)
    {
        if($(this).prop("checked") == true)
            {
                appendHtmlValue2("radio",$(this).attr("id"));
            }
            else
            {
                id= $(this).attr("id");
                $("#li"+id).remove();
            }
       
    });
   
    $(document).delegate("#datetimepicker4,#datetimepicker3","change",function(e)
    {
           appendHtmlValue2("dummy","dummy");
           
    });
     
    $(document).delegate("select.dynamicQues","change",function(e)
    {
       // alert();
           appendHtmlValue2("drop",$(this).attr("id"));
           
    }); 
     $(document).delegate("input.dynamicQues[type='text'],textarea.dynamicQues","keyup",function(e)
    {
        //alert();
           appendHtmlValue2("text",$(this).attr("id"));
           
    }); 
    
    var selectedOptions = [];
    function removeOldElements(item)
    {
      $("#li"+item).remove();
     $("."+item).remove();
    }

    function appendHtmlValue2(type,elementId)
    {

      var qnId = document.getElementById(elementId).getAttribute('for');
      var price = parseInt(($('#'+elementId).data('price')));
      if($("#serviceTotPrice").val() != '') {
        var priceArr = JSON.parse($("#serviceTotPrice").val());
      } else {
        var priceArr = [];
      }

      for (var i = 0; i < priceArr.length; i++) {
        
        if(priceArr[i]['qnId'] == qnId) {
          priceArr.splice(i, 1);
        }
      }


      priceArr.push({
          qnId : qnId, 
          price : price
      });

      $("#serviceTotPrice").val(JSON.stringify(priceArr));
      // (sessionStorage.getItem("serviceTotPrice") === undefined) ? sessionStorage.setItem("serviceTotPrice", price) : sessionStorage.setItem("serviceTotPrice", (sessionStorage.getItem("serviceTotPrice") + price))
      // var serviceTotPrice = sessionStorage.getItem("serviceTotPrice");
         

       // alert(type);
       // alert(elementId);
       selectedSummary="";
       scheduleDate = $("#datetimepicker4").val();
        scheduleTime = $("#datetimepicker3").val(); 
 //selectedSummary+= "<ul>";
 $('.answerRadios').each(function() {
     
    // $("#li"+$(this).attr("id")).remove();
     
     if($(this).prop("checked") == false)
            {
                id= $(this).attr("id");
                $("#li"+id).remove();
            }
            else
            {
                
            }
 
  // selectedSummary+="<li>"+$(this).attr("data-text")+"</li>";
});
/*$('select.dynamicQues:not(:selected)').each(function() 
{
 $(this).attr("id");
});*/
if(type=="radio")
{
    selectedOptions.push(elementId);
    selectedOptions.forEach(removeOldElements);

     $("#li"+elementId).remove();
     $("."+elementId).remove();
     selectedSummary+="<li id='li"+elementId+"' class='"+elementId+"'>"+$('#'+elementId).attr("data-text")+"</li>";
     
     sessionStorage.removeItem(elementId);
     sessionStorage.setItem(elementId, $('#'+elementId).val());
     
    // alert(selectedSummary);
}
if(type=="drop")
{
     valus = $('#'+elementId+' option:selected').html();
     //$(this).children("option:selected").val();
     $("#li"+elementId).remove();
     $("."+elementId).remove();
     if(valus!="Select" && valus!="select")
     {
     selectedSummary+="<li id='li"+elementId+"' class='"+elementId+"'>"+valus+"</li>";
     sessionStorage.removeItem(elementId);
     sessionStorage.setItem(elementId, $('#'+elementId).val());
     }else
     {
          sessionStorage.removeItem(elementId);
     }
}
if(type=="text")
{
     $("#li"+elementId).remove();
     $("."+elementId).remove();
     selectedSummary+="<li id='li"+elementId+"' class='"+elementId+"'>"+$('#'+elementId).val()+"</li>";
     sessionStorage.removeItem(elementId);
     sessionStorage.setItem(elementId, $('#'+elementId).val());
}

 //var selectedText = $(".dynamicQues option:selected").html();
//alert(selectedText);
if(scheduleDate!="")
    {
     $("#sheduleLi").remove();
     $(".sheduleLi").remove();
    selectedSummary+='<li id="sheduleLi" class="sheduleLi"> <b>Schedule</b> <span class="Adddate">'+scheduleDate+'</span> <span class="Addtime">'+scheduleTime+'</span></li>';
    }
 //selectedSummary+='<li> <b>Schedule</b> <span class="Adddate">29 May 2019</span> <span class="Addtime">6:45 PM</span></li>';
//selectedSummary+="</ul>";
       var priceArr = JSON.parse($("#serviceTotPrice").val());
       var currency = $("#serviceCurrency").val();
       serviceTotPrice = 0;
       for (var i = 0; i < priceArr.length; i++) {
        
        serviceTotPrice += priceArr[i]['price'];
        
      }
       $(".summaryUl").append(selectedSummary);
       $(".serviceTotPrice").text('Price '+currency+' '+serviceTotPrice);
       $("#serviceTotPricePass").val(serviceTotPrice);
       $(".noselect").html("");
    }
   function populateOldData()
   {
       $('.answerRadios').each(function() {
        $(this).prop("checked",false);
         id = $(this).attr("id");
         //alert(id);
        // alert(sessionStorage.getItem(id));
        if(sessionStorage.getItem(id)!="" && sessionStorage.getItem(id)!=null) 
        {
           // alert(sessionStorage.getItem(id));
            $(this).prop("checked",true);
        }
   
});
$('select.dynamicQues').each(function() {
 
     id = $(this).attr("id");
        if(sessionStorage.getItem(id)!="") 
        {
            $(this).val(sessionStorage.getItem(id));
        }
});

$('textarea.dynamicQues').each(function() {
 
          id = $(this).attr("id");
        if(sessionStorage.getItem(id)!="") 
        {
            $(this).val(sessionStorage.getItem(id));
        }
});
$('input.dynamicQues[type="text"]').each(function() {
 
   id = $(this).attr("id");
        if(sessionStorage.getItem(id)!="") 
        {
            $(this).val(sessionStorage.getItem(id));
        }
});
   }
    $( document ).ready(function() 
    {
        
    sessionStorage.clear();
    $("#firstButton").css("visibility","visible");
});
 $(document).delegate("#saveDynamicAddress","click",function(e)
    {
        
        $("#formDynamicLocation").submit();
           
    });

var validator=$("#formDynamicLocation").validate(
            //alert();
        {
           ignore: [],
        rules: 
        {
          
          "pickup-input2": 
          {
            required: true,
            maxlength: 100
            
          }
        },
       
        messages: 
        {
       
         },
     submitHandler: function ()
        {
			
		
            
                var formData = new FormData($("#formDynamicLocation")[0]);

                csrf_value  =   getCookie('csrf_cookie_name');  
                formData.append( "<?php echo $this->security->get_csrf_token_name();?>", csrf_value );
                
                     $.ajax({
             url: '<?php echo base_url();?>website/User/updateDynamicLocation',
             type: 'POST',
             data: formData,
             async: false,
             success: function (data) 
                {
                   debugger
                     data =  jQuery.parseJSON(data);
                    if(data['status']==1)
                    {
                        $(".pageWrapp").hide();
                         swal("Location has been updated successfully");
                         $("#formDynamicLocation")[0].reset();
                         $("#loactionUpdate").modal("hide");
                         $("#serviceLocation").val(data['address'].user_adresses_location);
                         $("#serviceAddress").val(JSON.stringify(data['address']));
                         $('.paymentOption').show();
                        
                    }
                    else
                    {
                         
                        if(data['errors'] !== "")
                          {
                            $.each(data['errors'], function(key, value) 
                            {
                              
                                 $( '<span class="error errorSpan1">'+value+'</span>' ).insertAfter( '[name="'+key+'"]');
                                

                            });   
                            
                            
                          }else
                          {    
                           
                           swal("Sorry!", "Failed to save! Try again later", "error");
                          
                          }
                    }
               },
             cache: false,
             contentType: false,
             processData: false
         });

                     return false;
      
        
                }
       
 }); 
 /* $(document).delegate(".homeType","click",function(e)
    {
        
        alert();
           
    });*/
 
</script>  
    
    
    
    

    
    

    
    
    
    
    





